﻿using System;

namespace AlanveHacim
{
    class Program
    {
        static void Main(string[] args)
        {
  
            double alan, hacim, islem, yaricap,yukseklik,cevre,yanal,a,b,c,kenaruzun;
            
            Console.WriteLine(" ALAN ve HACİM HESAPLAMA PROGRAMI\n ");
            Console.WriteLine(" 1 - Küre Alanı ve Hacmi Hesapla: ");
            Console.WriteLine(" 2 - Daire Alanı ve Çevre Hesapla: ");
            Console.WriteLine(" 3 - Silindir Alanı ve Hacmi Hesapla: ");
            Console.WriteLine(" 4 - Dikdörtgen Prizma Alanı ve Hacmi Hesapla: ");
            Console.WriteLine(" 5 - Küp Alanı ve Hacmi Hesapla: ");
            Console.Write("\n Lütfen seçiminizi gerçekleştiriniz : ");
            
            islem = Convert.ToInt16(Console.ReadLine());





            if(islem==1)
            {
                Console.Write("\n Kürenin yarı çapını (r) giriniz : ");
                yaricap = Convert.ToInt16(Console.ReadLine());
                alan = 4 * Math.PI * (yaricap * yaricap);
                hacim = 4/3 * Math.PI * (yaricap * yaricap * yaricap);
                Console.Write("\n Kürenin Alanı : " + alan);
                Console.Write("\n Kürenin Hacmi : " + hacim);

            }

            if (islem == 2)
            {
                Console.Write("\n Dairenin yarı çapını (r) giriniz :");
                yaricap = Convert.ToInt16(Console.ReadLine());
                alan = Math.PI * (yaricap * yaricap);
                cevre= Math.PI * yaricap * 2;
                Console.Write("\n Dairenin Alanı : " + alan);
                Console.Write("\n Darirenin Çevresi : " + cevre);

            }

            if (islem == 3)
            {
                Console.Write("\n Silindirin tavan ve taban dairesinin yarı çapını (r) giriniz : ");
                yaricap = Convert.ToInt16(Console.ReadLine());
                Console.Write("\n Silindirin yüksekliğini (h) giriniz : ");
                yukseklik = Convert.ToInt16(Console.ReadLine());
                alan = yukseklik * Math.PI * (yaricap * yaricap);
                yanal = 2 * Math.PI * yaricap * yukseklik;
                Console.Write("\n Silindirin Alanı : " + alan);
                Console.Write("\n Silindirin Yanal Alanı : " + yanal);

            }

            if (islem == 4)
            {
                Console.Write("\n Dikdörtgen Prizmanın A kenarı uzunluğunu  giriniz : ");
                a = Convert.ToInt16(Console.ReadLine());
                Console.Write("\n Dikdörtgen Prizmanın B kenarı uzunluğunu giriniz : ");
                b = Convert.ToInt16(Console.ReadLine());
                Console.Write("\n Dikdörtgen Prizmanın C kenarı uzunluğunu  giriniz : ");
                c = Convert.ToInt16(Console.ReadLine());
                alan = 2 * ((a * b) + (b * c) + (a * c)) ;
                hacim = a * b * c ;
                Console.Write("\n Dikdörtgen Prizmanın Alanı : " + alan);
                Console.Write("\n Dikdörtgen Prizmanın Hacmi : " + hacim);

            }

            if (islem == 5)
            {
                Console.Write("\n Küpün kenar uzunluğunu giriniz : ");
                kenaruzun = Convert.ToInt16(Console.ReadLine());
                alan = 6 * ( kenaruzun * kenaruzun );
                Console.Write("\n Küpün Alanı : " + alan);
                

            }

            Console.ReadKey();
        }
    }
}
