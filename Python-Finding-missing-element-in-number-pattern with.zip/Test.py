
dizi2=[]
dizi= input("Sayı Dizisini Giriniz: ")
a=0
e=1
k=1
aranan=0

dizi=dizi.split(",")


 #              YAPTIĞIM TÜM KONTROLLERDE HATA VEYA BİR PROBLEMLE KARŞILAŞMADIM.SORUNSUZ VE EKSİKSİZ ÇALIŞIYOR.


while a<len(dizi):

    if "?"==dizi[a]:
        aranan=a
    a +=1

if aranan==0:

    dizi.remove("?")
    a = 0
    while a<len(dizi):
        y=dizi[a]
        dizi2.append(int(y))
        a +=1

    if (dizi2[2]-dizi2[1])==(dizi2[1]-dizi2[0]):          #ARİTMATİK DİZİ

        f = dizi2[1] - dizi2[0]
        f = dizi2[0] - f
        print("Dizi aritmetik sayı dizisidir.\nBilinmeyen sayının değeri:",int(f) )


    elif (dizi2[2]/dizi2[1])==(dizi2[1]/dizi2[0]):        #GEOMETRİK DİZİ
        f = dizi2[1] / dizi2[0]
        f = dizi2[0] / f
        print("Dizi geometrik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    elif ((dizi2[2]**0.5)-(dizi2[1]**0.5))==((dizi2[1]**0.5)-(dizi2[0]**0.5)):       #KARESEL DİZİ
        f=(dizi2[1]**0.5)-(dizi2[0]**0.5)
        f=(dizi2[0]**0.5)-f
        f*=f

        print("Dizi karesel sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    else:
        f=dizi2[2]-dizi2[1]
        t=dizi2[1]-dizi2[0]
        k=f-t
        k=dizi2[0]-(t-k)
        print("Dizi üçgensel sayı dizisidir.\nBilinmeyen sayının değeri:", int(k))

elif aranan==1:

    dizi.remove("?")
    a=0
    while a < len(dizi):
        y = dizi[a]
        dizi2.append(int(y))
        a += 1

    if (dizi2[2] - dizi2[1])*2 == (dizi2[1] - dizi2[0]):  # ARİTMATİK DİZİ
        f = dizi2[2] - dizi2[1]
        f = dizi2[0] + f
        print("Dizi aritmetik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))


    elif (dizi2[2] / dizi2[1])*(dizi2[2] / dizi2[1]) == (dizi2[1] / dizi2[0]):  # GEOMETRİK DİZİ
        f = (dizi2[1] / dizi2[0])**0.5
        f = dizi2[0] * f
        print("Dizi geometrik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    elif ((dizi2[2] ** 0.5) - (dizi2[1] ** 0.5))*2 == ((dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)):  # KARESEL DİZİ
        f = (dizi2[2] ** 0.5) - (dizi2[1] ** 0.5)
        f = (dizi2[0] ** 0.5) + f
        f *= f

        print("Dizi karesel sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    else:
        b=1
        r=0
        say2=0
        while b>0:
            say2+=1
            r=dizi2[2]
            r-=b
            dizi2[2]=r
            b+=1
            if(r==0):
                b=-1
        c = 1
        s = 0
        say1 = 0
        while c > 0:
            say1 += 1
            s = dizi2[1]
            s -= c
            dizi2[1] = s
            c += 1
            if (s == 0):
                c = -1
        say=say2-say1
        sonsay=say2-(2*say)
        sonucc=0
        x=1
        while x<=sonsay :
            sonucc+=x
            x+=1

        print("Dizi üçgensel sayı dizisidir.\nBilinmeyen sayının değeri:", sonucc)

elif aranan==2:
    dizi.remove("?")
    a = 0
    while a < len(dizi):
        y = dizi[a]
        dizi2.append(int(y))
        a += 1

    if (dizi2[1] - dizi2[0]) * 2 == (dizi2[2] - dizi2[1]):  # ARİTMATİK DİZİ
        f = dizi2[1] - dizi2[0]
        f = dizi2[1] + f
        print("Dizi aritmetik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))


    elif (dizi2[1] / dizi2[0]) * (dizi2[1] / dizi2[0]) == (dizi2[2] / dizi2[1]):  # GEOMETRİK DİZİ
        f = (dizi2[2] / dizi2[1]) ** 0.5
        f = dizi2[1] * f
        print("Dizi geometrik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    elif ((dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)) * 2 == ((dizi2[2] ** 0.5) - (dizi2[1] ** 0.5)):  # KARESEL DİZİ
        f = (dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)
        f = (dizi2[1] ** 0.5) + f
        f *= f

        print("Dizi karesel sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    else:
        b = 1
        r = 0
        say2 = 0
        while b > 0:
            say2 += 1
            r = dizi2[1]
            r -= b
            dizi2[1] = r
            b += 1
            if (r == 0):
                b = -1
        c = 1
        s = 0
        say1 = 0
        while c > 0:
            say1 += 1
            s = dizi2[0]
            s -= c
            dizi2[0] = s
            c += 1
            if (s == 0):
                c = -1
        say = say2 - say1
        sonsay = say2 +  say
        sonucc = 0
        x = 1
        while x <= sonsay:
            sonucc += x
            x += 1

        print("Dizi üçgensel sayı dizisidir.\nBilinmeyen sayının değeri:", sonucc)

elif aranan==3:
    dizi.remove("?")
    a = 0
    while a < len(dizi):
        y = dizi[a]
        dizi2.append(int(y))
        a += 1

    if (dizi2[2] - dizi2[1]) == (dizi2[1] - dizi2[0]):  # ARİTMATİK DİZİ

        f = dizi2[1] - dizi2[0]
        f = dizi2[2] + f
        print("Dizi aritmetik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))


    elif (dizi2[2] / dizi2[1]) == (dizi2[1] / dizi2[0]):  # GEOMETRİK DİZİ
        f = dizi2[1] / dizi2[0]
        f = dizi2[2] * f
        print("Dizi geometrik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    elif ((dizi2[2] ** 0.5) - (dizi2[1] ** 0.5)) == ((dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)):  # KARESEL DİZİ
        f = (dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)
        f = (dizi2[2] ** 0.5) + f
        f *= f

        print("Dizi karesel sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    else:
        f = dizi2[2] - dizi2[1]
        t = dizi2[1] - dizi2[0]
        k = f - t
        k = dizi2[2] + k+f
        print("Dizi üçgensel sayı dizisidir.\nBilinmeyen sayının değeri:", int(k))

else:
    y=aranan
    dizi.remove("?")
    a = 0
    while a < len(dizi):
        y = dizi[a]
        dizi2.append(int(y))
        a += 1

    if (dizi2[2] - dizi2[1]) == (dizi2[1] - dizi2[0]):  # ARİTMATİK DİZİ

        f = dizi2[1] - dizi2[0]
        f = dizi2[aranan-1] + f
        print("Dizi aritmetik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))


    elif (dizi2[2] / dizi2[1]) == (dizi2[1] / dizi2[0]):  # GEOMETRİK DİZİ
        f = dizi2[1] / dizi2[0]
        f = dizi2[aranan-1] * f
        print("Dizi geometrik sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    elif ((dizi2[2] ** 0.5) - (dizi2[1] ** 0.5)) == ((dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)):  # KARESEL DİZİ
        f = (dizi2[1] ** 0.5) - (dizi2[0] ** 0.5)
        f = (dizi2[aranan-1] ** 0.5) + f
        f *= f

        print("Dizi karesel sayı dizisidir.\nBilinmeyen sayının değeri:", int(f))

    else:
        f = dizi2[2] - dizi2[1]
        t = dizi2[1] - dizi2[0]
        k = f - t
        k = dizi2[aranan-1] + k*(aranan-2) + f
        print("Dizi üçgensel sayı dizisidir.\nBilinmeyen sayının değeri:", int(k))



