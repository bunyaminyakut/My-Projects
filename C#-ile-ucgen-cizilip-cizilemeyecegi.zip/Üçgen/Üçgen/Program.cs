﻿using System;

namespace Üçgen
{
    class Program
    {
        static void Main(string[] args)
        {
            int ken1, ken2, ken3, buy = 0, ort = 0, kuc = 0;
            Console.WriteLine("\nÜçgen olabilme kontrol programına hoş geldiniz...\n");
            Console.Write("1.Kenarı giriniz : ");
            ken1 = Convert.ToInt16(Console.ReadLine());
            Console.Write("\n2.Kenarı giriniz : ");
            ken2 = Convert.ToInt16(Console.ReadLine());
            Console.Write("\nSon kenarı giriniz : ");
            ken3 = Convert.ToInt16(Console.ReadLine());

            if (ken1 > ken2 && ken1 > ken3)
            {
                buy = ken1;
                if (ken2 > ken3)
                {
                    ort = ken2;
                    kuc = ken3;
                }
                else
                {
                    ort = ken3;
                    kuc = ken2;
                }
            }

            else if (ken2 > ken2 && ken2 > ken3)
            {
                buy = ken2;
                if (ken1 > ken3)
                {
                    ort = ken1;
                    kuc = ken3;
                }
                else
                {
                    ort = ken3;
                    kuc = ken1;
                }
            }

            else if (ken3 > ken2 && ken3 > ken1)
            {
                buy = ken3;
                if (ken2 > ken1)
                {
                    ort = ken2;
                    kuc = ken1;
                }
                else
                {
                    ort = ken1;
                    kuc = ken2;
                }
            }
           
            if (((buy+kuc)>ort && ort>(buy-kuc) )&& ((ort+kuc)>buy && buy>(ort-kuc)) && ((buy+ort)>kuc && kuc>(buy-ort)))
            {
                Console.WriteLine("\n\nGirilen kenar uzunluklarıyla üçgen çizilebilir.");
            }
            else
                Console.WriteLine("\n\nÜzgünüm girilen kenar uzunluklarıyla üçgen çizilemez.");
            Console.ReadKey();
        }
    }
}
